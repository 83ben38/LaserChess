import acm.graphics.GCompound;
import acm.graphics.GLine;
import acm.graphics.GPolygon;
import acm.program.GraphicsProgram;
import svu.csc213.Dialog;

import java.awt.*;
import java.util.ArrayList;

public class LaserChess extends GraphicsProgram {
    static int[] size;
    static boolean teamTurn = false;
    static final int tileSize = 32;
    static boolean moved = false;
    static Map ace = rotateMap(() -> new String[][]{
            {"00b","00b","00b","00b","02s","00k","02s","02m","00b","00b"},
            {"00b","00b","01m","00b","00b","00b","00b","00b","00b","00b"},
            {"00b","00b","00b","10m","00b","00b","00b","00b","00b","00b"},
            {"03m","00b","11m","00b","01r","00r","00b","02m","00b","10m"},
            {"02m","00b","10m","00b","10r","11r","00b","03m","00b","11m"},
            {"00b","00b","00b","00b","00b","00b","02m","00b","00b","00b"},
            {"00b","00b","00b","00b","00b","00b","00b","13m","00b","00b"},
            {"00b","00b","10m","10s","10k","10s","00b","00b","00b","00b"},
    });
    static Map curiosity = rotateMap(() -> new String[][]{
            {"00b","00b","00b","00b","02s","00k","02s","02r","00b","00b"},
            {"00b","00b","00b","00b","00b","00b","00b","00b","00b","00b"},
            {"00b","00b","00b","10m","00b","00b","03m","00b","00b","00b"},
            {"03m","11m","00b","00b","12m","00r","00b","00b","02m","10m"},
            {"02m","10m","00b","00b","10r","00m","00b","00b","03m","11m"},
            {"00b","00b","00b","11m","00b","00b","02m","00b","00b","00b"},
            {"00b","00b","00b","00b","00b","00b","00b","00b","00b","00b"},
            {"00b","00b","10r","10s","10k","10s","00b","00b","00b","00b"},
    });
    static Map grail = rotateMap(() -> new String[][]{
            {"00b","00b","00b","00b","01m","02s","02m","00b","00b","00b"},
            {"00b","00b","00b","00b","00b","00k","00b","00b","00b","00b"},
            {"03m","00b","00b","00b","01m","02s","02r","00b","00b","00b"},
            {"02m","00b","01r","00b","10m","00b","12m","00b","00b","00b"},
            {"00b","00b","00b","00m","00b","02m","00b","11r","00b","10m"},
            {"00b","00b","00b","10r","10s","13m","00b","00b","00b","11m"},
            {"00b","00b","00b","00b","10k","00b","00b","00b","00b","00b"},
            {"00b","00b","00b","10m","10s","13m","00b","00b","00b","00b"},
    });
    static Map mercury = rotateMap(() -> new String[][]{
            {"00b","00b","00b","00b","01m","00k","02m","00b","00b","10r"},
            {"00b","00b","00b","00b","00b","02s","02m","00b","00b","00b"},
            {"02m","00b","00b","02r","00b","02s","00b","00b","00b","00b"},
            {"03m","00b","00b","00b","10m","00b","00b","00b","11m","00b"},
            {"00b","03m","00b","00b","00b","02m","00b","00b","00b","11m"},
            {"00b","00b","00b","00b","10s","00b","10r","00b","00b","10m"},
            {"00b","00b","00b","10m","10s","00b","00b","00b","00b","00b"},
            {"00r","00b","00b","10m","10k","13m","00b","00b","00b","00b"},
    });
    static Map sophie = rotateMap(() -> new String[][]{
            {"00b","00b","00b","00b","00k","10m","02m","00b","00b","00b"},
            {"00b","00b","00b","02s","00b","03s","00b","00b","00b","11m"},
            {"03m","00b","00b","00b","01m","02m","00b","10r","00b","10m"},
            {"00b","00b","00b","00b","00b","00b","00b","01r","00b","00b"},
            {"00b","00b","11r","00b","00b","00b","00b","00b","00b","00b"},
            {"02m","00b","00r","00b","10m","13m","00b","00b","00b","11m"},
            {"03m","00b","00b","00b","11s","00b","10s","00b","00b","00b"},
            {"00b","00b","00b","10m","02m","10k","00b","00b","00b","00b"},
    });
    static ArrayList<ArrayList<Piece>> board = new ArrayList<>();
    public static void main(String[] args) {
        new LaserChess().start();
    }

    @Override
    public void run() {
        Map map;
        String answer = Dialog.getString("Would you like ace, grail, mercury, sophie, or curiosity");
        while (!(answer.equalsIgnoreCase("ace") || answer.equalsIgnoreCase("grail") || answer.equalsIgnoreCase("curiosity") || answer.equalsIgnoreCase("mercury") || answer.equalsIgnoreCase("sophie"))){
            answer = Dialog.getString("Would you like ace, grail, mercury, sophie, or curiosity");
        }
        if (answer.equalsIgnoreCase("ace")){
            map = ace;
        }
        else if (answer.equalsIgnoreCase("grail")){
            map = grail;
        }
        else if (answer.equalsIgnoreCase("mercury")){
            map = mercury;
        }
        else if (answer.equalsIgnoreCase("sophie")){
            map = sophie;
        }
        else{
            map = curiosity;
        }
        doMap(map);
        while(true){
            teamTurn = !teamTurn;
            waitForMove();
            shootLaser(teamTurn);
        }
    }
    public void waitForMove(){
        moved = false;
        while(!moved){
            pause(1);
        }
    }
    public void doMap(Map map){
        size = new int[] {map.map().length, map.map()[0].length};
        for (int i = 0; i < size[0]; i++) {
            board.add(new ArrayList<>());
            for (int j = 0; j < size[1]; j++) {
                Piece piece = new Piece(map.map()[i][j].substring(2),map.map()[i][j].charAt(0) == '1',i,j, Integer.parseInt(map.map()[i][j].charAt(1) + ""));
                add(piece,i*tileSize,j*tileSize);
                board.get(i).add(piece);
            }
        }
    }
    public void shootLaser(boolean team){
        ArrayList<GLine> l;
        if (!team){
            l = shootLaser(new int[]{0,-1},new int[]{0,1},Color.red, new ArrayList<>());
        }
        else{
            l = shootLaser(new int[]{size[0]-1,size[1]},new int[]{0,-1},Color.blue, new ArrayList<>());
        }
        pause(1000);
        while (l.size() > 0){
            remove(l.get(0));
            l.remove(0);
        }
    }
    public ArrayList<GLine> shootLaser(int[] current, int[] goingTo, Color color, ArrayList<GLine> p){
        GLine laser = new GLine((current[0] + 0.5)*tileSize,(current[1] + 0.5)*tileSize, (current[0]+ goingTo[0] + 0.5)*tileSize, (current[1] + goingTo[1] + 0.5)*tileSize);
        laser.setColor(color);
        add(laser);
        p.add(laser);
        int[] move;
        try {
            move = board.get(current[0] + goingTo[0]).get(current[1] + goingTo[1]).moveLaser(-goingTo[0], -goingTo[1]);
        }
        catch(IndexOutOfBoundsException e){
            return p;
        }
        if (move.length <  1){
            return p;
        }
        current[0] += goingTo[0];
        current[1] += goingTo[1];
        pause(100);
        return shootLaser(current,move,color, p);
    }
    public static Map rotateMap(Map map){
        String[][] results = new String[map.map()[0].length][map.map().length];
        for (int i = 0; i < map.map().length; i++) {
            for (int j = 0; j < map.map()[0].length; j++) {
                results[j][i] = map.map()[i][j];
            }
        }
        return () -> results;
    }
}
